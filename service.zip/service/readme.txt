=== Service ===
Contributors: serviceonline
Tags: crm, service
Requires at least: 4.7
Tested up to: 5.7.2
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This plugin allows you to track orders in the service center

== Changelog ==
= 1.0.0 =
Initial release.


