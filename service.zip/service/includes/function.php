<?php

add_action('wp_ajax_insert_client_number', function (){
	global $wpdb;
	$service_search_number = sanitize_text_field($_GET['search_number']);
	wp_send_json($wpdb->get_row("SELECT client FROM $wpdb->service_orders WHERE `number`=".$service_search_number, ARRAY_A));
});

add_action('wp_ajax_live_search', function (){
	global $wpdb;
	$service_field = sanitize_text_field($_GET['field']);
	$service_search = sanitize_text_field($_GET['search']);
	wp_send_json($wpdb->get_col("SELECT distinct(".$service_field.") FROM $wpdb->service_orders WHERE ".$service_field." LIKE '".$service_search."%' ORDER BY ".$service_field." ASC"));
});

add_action('wp_ajax_delete_orders', function (){
	if (current_user_can('manage_options')) {
		global $wpdb;
		$data = 0;
		foreach ($_GET['delete'] as $del_id) {
			$data[] = $del_id;
		}
		$data = implode(",", $data);
		wp_send_json($wpdb->query("DELETE FROM $wpdb->service_orders WHERE `id` in ($data)"));
	} else {
		wp_send_json('Not enough rights to delete an object!');
	}
});

add_action('wp_ajax_update_order_info', function (){
	global $wpdb;
	$service_status =     sanitize_text_field($_POST['status']);
	$service_work =       sanitize_text_field($_POST['work']);
	$service_cost_spare = sanitize_text_field($_POST['cost_spare']);
	$service_cost_total = sanitize_text_field($_POST['cost_total']);
	$service_id =         sanitize_text_field($_POST['id']);
	$res = $wpdb->update($wpdb->service_orders,
		['status' => $service_status, 'work' => $service_work, 'cost_spare' => $service_cost_spare, 'cost_total' => $service_cost_total],
		['id' => $service_id]
	);
	if ($service_status == 7){
		$wpdb->update($wpdb->service_orders, ['date_issue' => date('Y.m.d H:i:s')], ['id' => $service_id]);
	}
	wp_send_json($res);
});