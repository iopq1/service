<div id="chart_eth" style="width: 100%; height: 100%;"></div>
<div id="chart_etc" style="width: 100%; height: 100%;"></div>
<div style="text-align: center;"><img id="loadImg" style="width: 5%; height: 5%;" src="<?php echo plugins_url( 'load.gif', __FILE__ );?>" /></div>
<p><button id="ref" class="button">Refresh</button></p>

<script>
    jQuery(document).ready(function($) {

        google.charts.load('current', {packages: ['corechart']});
        function googleChart(title, elem, rows) {
            google.charts.setOnLoadCallback(function () {
                const data = new google.visualization.DataTable();
                data.addColumn('number', 'Time');
                data.addColumn('number', 'Hashrate (GH/s)');
                data.addColumn('number', 'Miners');
                data.addColumn('number', 'Workers');
                data.addColumn('number', 'exchangeRates');
                data.addRows(rows);
                const chart = new google.visualization.AreaChart(document.getElementById(elem));
                chart.draw(data, {title: title});
            });
        }

        function refresh(){
            $("#loadImg").show();
            $("#ref").hide();
            $("#chart_eth").hide();
            $("#chart_etc").hide();

            $.get('<?php echo get_rest_url(0, 'hivestats/data');?>', {table: 'wp_hivestat_eth'}, function (data) {
                googleChart('HivePoolETH', 'chart_eth', data);
                $("#chart_eth").show();
            });

            $.get('<?php echo get_rest_url(0, 'hivestats/data');?>', {table: 'wp_hivestat_etc'}, function (data) {
                googleChart('HivePoolETC', 'chart_etc', data);
                $("#loadImg").hide();

                $("#chart_etc").show();
                $("#ref").show();
            });

        }

        $("#ref").click(function(){
            refresh();
        });

        refresh();

    });

</script>