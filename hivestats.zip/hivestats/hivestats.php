<?php
/**
 * Plugin Name:       HiveStats
 * Description:       Collect statistics HiveOS pool
 * Version:           1.0.0
 * Requires at least: 5.9.2
 * Requires PHP:      8.0
 * Author:            serviceonline
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) die;

global $wpdb;
$wpdb->hivestat_etc = $wpdb->prefix.'hivestat_etc';
$wpdb->hivestat_eth = $wpdb->prefix.'hivestat_eth';

add_action('admin_menu', function (){
    $page = add_menu_page(
        'HiveStats',
        'HiveStats',
        'service_user',
        'statistics.php',
        function() { include 'statistics.php'; },
        'dashicons-dashboard',
        '100');
    add_action( 'load-' . $page, function (){
        wp_enqueue_script( 'google_charts', plugins_url('/js/google.charts.js', __FILE__) );
    });
});

add_action('rest_api_init', function (){

    register_rest_route('hivestats', 'data', [
        'methods' => 'GET',
        'callback' => function($request_data){
            $parameters = $request_data->get_params();
            if ( !isset($parameters['table']) or empty($parameters['table'])) return 'Something went wrong';
            global $wpdb;
            $result = $wpdb->get_results("SELECT `exchangeRates`, `hashrate`, `miners`, `workers` FROM $parameters[table]", ARRAY_A);
            $data =[];
            $i = 0;
            foreach ($result as $row){
                $data[] = [++$i, ceil((int)$row['hashrate']) / 1000000000, (int)$row['miners'], (int)$row['workers'], (int)$row['exchangeRates']];
            }
            wp_send_json($data);
        }
    ]);

});

function insertDB($table, $result){
    global $wpdb;
    $wpdb->insert($table,
        [
            'blocksFound'           => $result->blocksFound,
            'exchangeRates'         => $result->exchangeRates->USD,
            'expectedReward24H'     => $result->expectedReward24H,
            'hashrate'              => $result->hashrate,
            'meanExpectedReward24H' => $result->meanExpectedReward24H,
            'miners'                => $result->miners,
            'workers'               => $result->workers
        ]
    );
}

add_action( 'hivestats', function() {
    $res = json_decode(file_get_contents("https://hiveon.net/api/v1/stats/pool"));
    insertDB('wp_hivestat_eth', $res->stats->ETH);
    insertDB('wp_hivestat_etc', $res->stats->ETC);
});

add_filter( 'cron_schedules', function () {
    $schedules['one_minute'] = ['interval' => 60, 'display' => 'Once a minute'];
    return $schedules;
});

register_activation_hook(__FILE__, function () {

    if ( ! wp_next_scheduled( 'hivestats' ) )
        wp_schedule_event( time(), 'one_minute', 'hivestats' ); //hourly

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    global $wpdb;
    $sql = "CREATE TABLE {$wpdb->hivestat_etc} (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `blocksFound` int(11) NOT NULL,
      `exchangeRates` double NOT NULL,
      `expectedReward24H` double NOT NULL,
      `hashrate` double NOT NULL,
      `meanExpectedReward24H` double NOT NULL,
      `miners` int(11) NOT NULL,
      `workers` int(11) NOT NULL,
  UNIQUE KEY id (id)
) DEFAULT CHARACTER SET {$wpdb->charset} COLLATE {$wpdb->collate};";
    dbDelta($sql);

    $sql = "CREATE TABLE {$wpdb->hivestat_eth} (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `blocksFound` int(11) NOT NULL,
      `exchangeRates` double NOT NULL,
      `expectedReward24H` double NOT NULL,
      `hashrate` double NOT NULL,
      `meanExpectedReward24H` double NOT NULL,
      `miners` int(11) NOT NULL,
      `workers` int(11) NOT NULL,
  UNIQUE KEY id (id)
) DEFAULT CHARACTER SET {$wpdb->charset} COLLATE {$wpdb->collate};";
    dbDelta($sql);

});

register_deactivation_hook(__FILE__, function (){
    wp_clear_scheduled_hook( 'hivestats' );
});